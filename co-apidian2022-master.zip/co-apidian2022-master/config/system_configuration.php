<?php

return [
    'allow_public_download' => env('ALLOW_PUBLIC_DOWNLOAD', true), 
];
