<cac:AdditionalDocumentReference>
    <cbc:ID>{{preg_replace("/[\r\n|\n|\r]+/", "", $AdditionalDocumentReferenceID)}}</cbc:ID>
    <cbc:IssueDate>{{preg_replace("/[\r\n|\n|\r]+/", "", $AdditionalDocumentReferenceDate)}}</cbc:IssueDate>
    <cbc:DocumentTypeCode>{{preg_replace("/[\r\n|\n|\r]+/", "", $AdditionalDocumentReferenceTypeDocument)}}</cbc:DocumentTypeCode>
</cac:AdditionalDocumentReference>
